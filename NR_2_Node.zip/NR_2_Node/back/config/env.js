// Control ==========================================
// const env = {
//     database: 'Node',
//     // database: 'Node_32',
//     username: 'wal',
//     password: '0101',
//     host: '192.168.0.31',
//     // host: '192.168.0.32',
//     dialect: 'mysql',
//     pool: {
//         max: 5,
//         min: 0,
//         acquire: 30000,
//         idle: 10000
//     }
     
//   };
   
//   module.exports = env;
  
  // Silvio ==========================================
  
  const env = {
    database: 'ddbeng30_teste',
    username: 'ddbeng30',
    password: 'X2cVnom385',
    host: '162.241.2.79',
    dialect: 'mysql',
    pool: {
  	  max: 5,
  	  min: 0,
  	  acquire: 30000,
  	  idle: 10000
    }
     
  };
   
  module.exports = env;
  
  